import os, time, requests
import pandas as pd
import numpy as np

API=os.getenv("TWELVEDATA_API_KEY","PASTE_TWELVE_DATA_KEY_HERE")
TOKEN=os.getenv("TELEGRAM_BOT_TOKEN","PASTE_TELEGRAM_BOT_TOKEN_HERE")
CHAT=os.getenv("TELEGRAM_CHAT_ID","PASTE_TELEGRAM_CHAT_ID_HERE")

def get_data():
    p={"symbol":"EUR/USD","interval":"15min","outputsize":250,"apikey":API,"order":"ASC","timezone":"UTC"}
    j=requests.get("https://api.twelvedata.com/time_series",params=p,timeout=20).json()
    if "values" not in j: raise RuntimeError(j.get("message",j))
    d=pd.DataFrame(j["values"])
    for c in ["open","high","low","close"]: d[c]=pd.to_numeric(d[c])
    d["datetime"]=pd.to_datetime(d["datetime"],utc=True)
    return d.sort_values("datetime").reset_index(drop=True)

def indicators(d):
    c=d.close; h=d.high; l=d.low
    d["e20"]=c.ewm(span=20,adjust=False).mean()
    d["e50"]=c.ewm(span=50,adjust=False).mean()
    d["e200"]=c.ewm(span=200,adjust=False).mean()
    delta=c.diff(); gain=delta.clip(lower=0); loss=-delta.clip(upper=0)
    ag=gain.ewm(alpha=1/14,adjust=False).mean()
    al=loss.ewm(alpha=1/14,adjust=False).mean()
    d["rsi"]=(100-100/(1+ag/al.replace(0,np.nan))).fillna(50)
    pc=c.shift(1)
    tr=pd.concat([h-l,(h-pc).abs(),(l-pc).abs()],axis=1).max(axis=1)
    d["atr"]=tr.ewm(alpha=1/14,adjust=False).mean()
    return d

def signal(d):
    a=d.iloc[-2]; b=d.iloc[-3]
    buy=a.e20>a.e50>a.e200 and a.close>a.e200 and b.rsi<=45<a.rsi and a.close>a.e20
    sell=a.e20<a.e50<a.e200 and a.close<a.e200 and b.rsi>=55>a.rsi and a.close<a.e20
    if not (buy or sell): return None
    side="BUY" if buy else "SELL"; p=float(a.close); atr=float(a.atr)
    sd=max(atr*1.5,0.0008); td=sd*1.5
    if side=="BUY": sl=p-sd; tp1=p+td; tp2=p+td*1.5
    else: sl=p+sd; tp1=p-td; tp2=p-td*1.5
    return f"{'🟢' if buy else '🔴'} EURUSD M15 {side}\n\nEntry: {p:.5f}\nSL: {sl:.5f}\nTP1: {tp1:.5f}\nTP2: {tp2:.5f}\n\nRSI: {a.rsi:.1f}\nATR: {atr:.5f}\nLot guide: 0.01 maximum*\n\n⚠️ R200 account: high risk. Signal only; no guaranteed profit.\n*Confirm broker minimum lot, contract size and margin."

def send(text):
    r=requests.post(f"https://api.telegram.org/bot{TOKEN}/sendMessage",json={"chat_id":CHAT,"text":text},timeout=20)
    r.raise_for_status()

if __name__=="__main__":
    if "PASTE_" in API+TOKEN+CHAT: raise SystemExit("Set the three environment variables first.")
    send("🤖 R200 EURUSD bot online. Monitoring EUR/USD M15.")
    last=None
    while True:
        try:
            s=signal(indicators(get_data()))
            if s and s!=last: send(s); last=s
        except Exception as e: print("ERROR:",e,flush=True)
        time.sleep(60)
