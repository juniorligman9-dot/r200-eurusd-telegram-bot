R200 EURUSD Telegram signal bot. Do not upload API keys or tokens to GitHub.
Install: pip install -r requirements.txt
Set TWELVEDATA_API_KEY, TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID.
Run: python r200_eurusd_telegram_bot.py
